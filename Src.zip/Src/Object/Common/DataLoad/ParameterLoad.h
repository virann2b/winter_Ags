#pragma once

#include <map>
#include <vector>
#include <string>

struct Vector3;
struct Vector2;
struct Vector2I;

class ParameterLoad
{
public:
    // �t�H���_�p�X���󂯎��
    ParameterLoad(const std::string& directoryPath);

    ~ParameterLoad() = default;

    bool IsParameterExist(
        const std::string& fileName,
		const std::string& parameterName) const;

    // �z�񂲂Ǝ擾
    const std::vector<float>& GetParameterArray(
        const std::string& fileName,
        const std::string& parameterName) const;

    // ���̂܂�float�^�Ƃ��Ď擾
    float GetParameter(
        const std::string& fileName,
        const std::string& parameterName,
        int index = 0) const;

    /// int�^�ɃL���X�g���Ď擾
    int GetParameterToInt(
        const std::string& fileName,
        const std::string& parameterName,
        int index = 0) const;

    /// Vector3�^�Ƃ��Ď擾
    Vector3 GetParameterToVector3(
        const std::string& fileName,
        const std::string& parameterName) const;

    /// Vector2�^�Ƃ��Ď擾
    Vector2 GetParameterToVector2(
        const std::string& fileName,
        const std::string& parameterName) const;

    /// Vector2I�^�Ƃ��Ď擾
    Vector2I GetParameterToVector2I(
        const std::string& fileName,
        const std::string& parameterName) const;

    void Release(void);

private:

    // CSV�t�@�C����ǂݍ��ފ֐�
    void LoadCsvFile(const std::string& filePath, const std::string& fileName);

    // �p�����[�^���̗�
    static constexpr int PARAMETER_NAME_INDEX = 0;

	// �p�����[�^���i�[����}�b�v
    std::map<std::string, std::map<std::string, std::vector<float>>> parameterMap;
};