#include "ParameterLoad.h"

#include <filesystem>
#include <fstream>
#include <iostream>

#include "../../../Utility/Utility.h"

namespace fs = std::filesystem;

ParameterLoad::ParameterLoad(const std::string& directoryPath)
{
    // �t�H���_���𑖍�
    for (const auto& entry : fs::directory_iterator(directoryPath)) {
        // �t�@�C������Ȃ���΃X�L�b�v
        if (!entry.is_regular_file()) { continue; }

        // �g���q�擾
        const fs::path& path = entry.path();

        // .csv����Ȃ���΃X�L�b�v
        if (path.extension() != ".csv") { continue; }

        // �t�@�C�����̂ݎ擾�i�g���q�Ȃ��j
        std::string fileName = path.stem().string();

        // CSV�ǂݍ���
        LoadCsvFile(path.string(), fileName);
    }
}

void ParameterLoad::LoadCsvFile(const std::string& filePath, const std::string& fileName)
{
    std::ifstream ifs(filePath);

    if (!ifs) {
        std::cerr << "CSV�t�@�C�����J���܂���ł��� : " << filePath << std::endl;
        return;
    }

    std::string line;

    while (getline(ifs, line)) {
        // �J���}��؂�
        std::vector<std::string> parameterStringArray = Split(line, ',');

        // �f�[�^�s���Ȃ�X�L�b�v
        if (parameterStringArray.empty()) { continue; }

        std::string parameterName;
        std::vector<float> values;

        for (size_t i = 0; i < parameterStringArray.size(); i++) {
            if (i == PARAMETER_NAME_INDEX) { parameterName = parameterStringArray[i]; }
            else { values.emplace_back(std::stof(parameterStringArray[i])); }
        }

        // �ۑ�
        parameterMap[fileName][parameterName] = values;
    }
}

bool ParameterLoad::IsParameterExist(const std::string& fileName, const std::string& parameterName) const
{
    auto fileIt = parameterMap.find(fileName);
    if (fileIt == parameterMap.end()) { return false; }
    const auto& parameterMapForFile = fileIt->second;
	return parameterMapForFile.find(parameterName) != parameterMapForFile.end();
}

const std::vector<float>& ParameterLoad::GetParameterArray(const std::string& fileName, const std::string& parameterName) const
{
    return parameterMap.at(fileName).at(parameterName);
}

float ParameterLoad::GetParameter(const std::string& fileName, const std::string& parameterName, int index) const
{
    return parameterMap.at(fileName).at(parameterName).at(index);
}

int ParameterLoad::GetParameterToInt(const std::string& fileName, const std::string& parameterName, int index) const
{
    return static_cast<int>(GetParameter(fileName, parameterName, index));
}

Vector3 ParameterLoad::GetParameterToVector3(const std::string& fileName, const std::string& parameterName) const 
{
    const std::vector<float>& param = GetParameterArray(fileName, parameterName);

    // �v�f���s��v
    if (param.size() != 3) { return Vector3(); }

    return Vector3(param[0], param[1], param[2]);
}

Vector2 ParameterLoad::GetParameterToVector2(const std::string& fileName, const std::string& parameterName) const
{
    const std::vector<float>& param = GetParameterArray(fileName, parameterName);

    // �v�f���s��v
    if (param.size() != 2) { return Vector2(); }

    return Vector2(param[0], param[1]);
}

Vector2I ParameterLoad::GetParameterToVector2I(const std::string& fileName, const std::string& parameterName) const
{
    const std::vector<float>& param = GetParameterArray(fileName, parameterName);

    // �v�f���s��v
    if (param.size() != 2) { return Vector2I(); }

    return Vector2I(param[0], param[1]);
}

void ParameterLoad::Release(void) { parameterMap.clear(); }