#pragma once

class CameraBase;

class CameraEventBase
{
public:

    CameraEventBase() = default;

    virtual ~CameraEventBase() = default;

    // �J�n
    virtual void Start(CameraBase& camera) {}

    // �X�V
    virtual void Update(CameraBase& camera) = 0;

    // �I��
    virtual void End(CameraBase& camera) {}

    // �I��������
    virtual bool IsEnd(void) const = 0;
};