#pragma once

#include "../Common/GameSpace/WorldSceneBase.h"

class GameScene : public WorldSceneBase
{
public:
	GameScene();
	~GameScene()override = default;

private:

#pragma region ��v�֐��Ē�`

	// �ǂݍ���
	void SubPostLoad(void)override;

	// �X�V
	void SubWorldPostUpdate(void)override;

	// UI�`��
	void SubUiDraw(void)override;

#pragma endregion

	void CreateCamera(void)override;
};