#pragma once
#include "../pch.h"

#include <string>
#include <vector>

#include <fstream>
#include <sstream>


#include "../Common/Vector2.h"
#include "../Common/Vector2I.h"
#include "../Common/Vector3.h"

// ���W�A��(rad)�E�x(deg)�ϊ��p
static constexpr float RAD2DEG = (180.0f / DX_PI_F);
static constexpr float DEG2RAD = (DX_PI_F / 180.0f);

static constexpr float kEpsilonNormalSqrt = 1e-15F;

// �l�̌ܓ�
static int Round(float v) { return static_cast<int>(roundf(v)); }

// ������̕���
static std::vector <std::string> Split(std::string& line, char delimiter) {
    std::istringstream stream(line);
	std::string field;
	std::vector<std::string> result;

	while (getline(stream, field, delimiter)) {
		result.push_back(field);
	}

	return result;
}

// ���W�A��(rad)����x(deg)
static double Rad2Deg(double rad) { return rad * (180.0 / DX_PI); }
static float Rad2Deg(float rad) { return rad * (180.0f / DX_PI_F); }
static int Rad2Deg(int rad) { return rad * Round(180.0f / DX_PI_F); }

// �x(deg)���烉�W�A��(rad)
static double Deg2Rad(double deg) { return deg * (DX_PI / 180.0); }
static float Deg2Rad(float deg) { return deg * (DX_PI_F / 180.0f); }
static int Deg2Rad(int deg) { return deg * Round(DX_PI_F / 180.0f); }
static VECTOR Deg2Rad(const VECTOR& deg) { return { Deg2Rad(deg.x),Deg2Rad(deg.y),Deg2Rad(deg.z) }; }
static Vector3 Deg2Rad(const Vector3& deg) { return { Deg2Rad(deg.x),Deg2Rad(deg.y),Deg2Rad(deg.z) }; }

// 0�`360�x�͈̔͂Ɏ��߂�
static double DegIn360(double deg) {
	deg = fmod(deg, 360.0);
	if (deg < 0.0f)
	{
		deg += 360.0;
	}
	return deg;
}

// 0(0)�`2��(360�x)�͈̔͂Ɏ��߂�
static double RadIn2PI(double rad) {
	rad = fmod(rad, DX_TWO_PI);
	if (rad < 0.0)
	{
		rad += DX_TWO_PI;
	}
	return rad;
}

// ��]�����Ȃ����̉�]�������擾����(���v���:1�A�����v���:-1)
static int DirNearAroundRad(float from, float to) {
	float ret = 1.0f;

	float diff = to - from;

	if (diff >= 0.0f) {
		// ��r���������v���Ɉʒu����

		// �ł��A180�x�ȏ㗣��Ă���̂ŁA�����v���̕����߂�
		if (diff > DX_PI_F) { ret = -1.0f; }
		// ���v���
		else { ret = 1.0f; }

	}
	else {
		// ��r�����������v���Ɉʒu����

		// �ł��A180�x�ȏ㗣��Ă���̂ŁA���v���̕����߂�
		if (diff < -DX_PI_F) { ret = 1.0f; }
		// �����v���
		else { ret = -1.0f; }
	}

	return static_cast<int>(ret);
}

// ��]�����Ȃ����̉�]�������擾����(���v���:1�A�����v���:-1)
static int DirNearAroundDeg(float from, float to) {
	float ret = 1.0f;

	float diff = to - from;

	if (diff >= 0.0f) {
		// ��r���������v���Ɉʒu����

		// �ł��A180�x�ȏ㗣��Ă���̂ŁA�����v���̕����߂�
		if (diff > 180.0f) { ret = -1.0f; }
		// ���v���
		else { ret = 1.0f; }
	}
	else	{
		// ��r�����������v���Ɉʒu����

		// �ł��A180�x�ȏ㗣��Ă���̂ŁA���v���̕����߂�
		if (diff < -180.0f) { ret = 1.0f; }
		// �����v���
		else { ret = -1.0f; }
	}

	return static_cast<int>(ret);
}

// ���`���
static int Lerp(int start, int end, float t) {
	if (t >= 1.0f) { return end; }

	int ret = start;
	ret += Round(t * static_cast<float>(end - start));
	return ret;
}
static float Lerp(float start, float end, float t) {
	if (t >= 1.0f) { return end; }

	float ret = start;
	ret += t * (end - start);
	return ret;
}
static double Lerp(double start, double end, double t) {
	if (t >= 1.0) { return end; }

	double ret = start;
	ret += t * (end - start);
	return ret;
}
static Vector2 Lerp(const Vector2& start, const Vector2& end, float t) {
	if (t >= 1.0f) { return end; }

	Vector2 ret = start;
	ret.x += Round(t * static_cast<float>((end.x - start.x)));
	ret.y += Round(t * static_cast<float>((end.y - start.y)));
	return ret;
}

// �p�x�̐��`���
static double LerpDeg(double start, double end, double t) {
	double ret;

	double diff = end - start;
	if (diff < -180.0) {
		end += 360.0;
		ret = Lerp(start, end, t);
		if (ret >= 360.0) { ret -= 360.0; }
	}
	else if (diff > 180.0) {
		end -= 360.0;
		ret = Lerp(start, end, t);
		if (ret < 0.0) { ret += 360.0; }
	}
	else { ret = Lerp(start, end, t); }

	return ret;
}

// �x�W�F�Ȑ�
static Vector2 Bezier(const Vector2& p1, const Vector2& p2, const Vector2& p3, float t) {
	Vector2 a = Lerp(p1, p2, t);
	Vector2 b = Lerp(p2, p3, t);
	return Lerp(a, b, t);
}

static float Signed(float x) { return (x < 0) ? -1.0f : 1.0f; }

// �摜�ǂݍ��݁i�G���[�`�F�b�N�t���j
static void LoadImg(int& handle, std::string path) {
	handle = LoadGraph(path.c_str());
	if (handle == -1) {
		printfDx("�摜�ǂݍ��݂Ɏ��s���܂���");
	}
}
// �摜�ǂݍ��݁i�G���[�`�F�b�N�t���j
static int LoadImg(std::string path) {
	int ret = 0;

	ret = LoadGraph(path.c_str());
	if (ret == -1) {
		printfDx("�摜�ǂݍ��݂Ɏ��s���܂���");
	}

	return ret;
}

// �X�v���C�g�摜�ǂݍ��݁i�G���[�`�F�b�N�t���j
static void LoadArrayImg(std::string path, int AllNum, int XNum, int YNum, int XSize, int YSize, int* handleArray) {
	int err = 0;

	err = LoadDivGraph(path.c_str(), AllNum, XNum, YNum, XSize, YSize, handleArray);

	if (err == -1) {
		printfDx("�摜�ǂݍ��݂Ɏ��s���܂���");
	}
}

static void LoadArrayImg(std::string path, int AllNum, int XNum, int YNum, int XSize, int YSize, std::vector<int>& handleArray) {
	handleArray.resize(AllNum);

	int err = LoadDivGraph(path.c_str(), AllNum, XNum, YNum, XSize, YSize, handleArray.data());

	if (err == -1) {
		printfDx("�摜�ǂݍ��݂Ɏ��s���܂���: %s\n", path.c_str());
		return;
	}
}


#pragma region �e���Ԃ́iVECTOR or Vector3�j�\���̂��s��ɕϊ�����֐��i�����ɂ����ł��������d�l �����珇�Ɍv�Z�����j
    static MATRIX MatrixAllMultX(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) { m = MMult(m, MGetRotX(vec.x)); }
        return m;
    }

    static MATRIX MatrixAllMultX(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) { m = MMult(m, MGetRotX(vec.x)); }
        return m;
    }

    static MATRIX MatrixAllMultY(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) { m = MMult(m, MGetRotY(vec.y)); }
        return m;
    }

    static MATRIX MatrixAllMultY(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) { m = MMult(m, MGetRotY(vec.y)); }
        return m;
    }

    static MATRIX MatrixAllMultZ(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) { m = MMult(m, MGetRotZ(vec.z)); }
        return m;
    }

    static MATRIX MatrixAllMultZ(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) { m = MMult(m, MGetRotZ(vec.z)); }
        return m;
    }

    static MATRIX MatrixAllMultXY(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultXY(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultXZ(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultXZ(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultXYZ(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultXYZ(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultXZY(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultXZY(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultYX(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }

    static MATRIX MatrixAllMultYX(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }

    static MATRIX MatrixAllMultYZ(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultYZ(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultYXZ(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultYXZ(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotZ(vec.z));
        }
        return m;
    }

    static MATRIX MatrixAllMultYZX(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }

    static MATRIX MatrixAllMultYZX(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }

    static MATRIX MatrixAllMultZX(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }

    static MATRIX MatrixAllMultZX(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }

    static MATRIX MatrixAllMultZY(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultZY(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultZXY(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultZXY(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotX(vec.x));
            m = MMult(m, MGetRotY(vec.y));
        }
        return m;
    }

    static MATRIX MatrixAllMultZYX(const std::initializer_list<VECTOR>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }

    static MATRIX MatrixAllMultZYX(const std::initializer_list<Vector3>& vecs) {
        MATRIX m = MGetIdent();
        for (const auto& vec : vecs) {
            m = MMult(m, MGetRotZ(vec.z));
            m = MMult(m, MGetRotY(vec.y));
            m = MMult(m, MGetRotX(vec.x));
        }
        return m;
    }
#pragma endregion

// �s������������f���̍��W�ƌ����̃Z�b�g
static void MV1ModelMatrix(int& model, const VECTOR& pos, const std::initializer_list<VECTOR>& angle) {
    MATRIX m = MGetIdent();
    // �p�x�Z�b�g�����ɍ���
    for (const auto& a : angle) {
        m = MMult(m, MGetRotX(a.x));
        m = MMult(m, MGetRotY(a.y));
        m = MMult(m, MGetRotZ(a.z));
    }

    MV1SetRotationMatrix(model, m);
    MV1SetPosition(model, pos);
}
static void MV1ModelMatrix(int& model, const Vector3& pos, const std::initializer_list<Vector3>& angle) {
    MATRIX m = MGetIdent();
    // �p�x�Z�b�g�����ɍ���
    for (const auto& a : angle) {
        m = MMult(m, MGetRotX(a.x));
        m = MMult(m, MGetRotY(a.y));
        m = MMult(m, MGetRotZ(a.z));
    }

    MV1SetRotationMatrix(model, m);
    MV1SetPosition(model, pos.ToVECTOR());
}

static void MV1ModelMatrix(int& model, const VECTOR& scale, const VECTOR& pos, const std::initializer_list<VECTOR>& angle) {
    MATRIX m = MGetIdent();

    m.m[0][0] = scale.x;
    m.m[1][1] = scale.y;
    m.m[2][2] = scale.z;

    // �p�x�Z�b�g�����ɍ���
    for (const auto& a : angle) {
        m = MMult(m, MGetRotX(a.x));
        m = MMult(m, MGetRotY(a.y));
        m = MMult(m, MGetRotZ(a.z));
    }

    m.m[3][0] = pos.x;
    m.m[3][1] = pos.y;
    m.m[3][2] = pos.z;

    MV1SetMatrix(model, m);
}
static void MV1ModelMatrix(int& model, const Vector3& scale, const Vector3& pos, const std::initializer_list<Vector3>& angle) {
    MATRIX m = MGetIdent();

    m.m[0][0] = scale.x;
    m.m[1][1] = scale.y;
    m.m[2][2] = scale.z;

    // �p�x�Z�b�g�����ɍ���
    for (const auto& a : angle) {
        m = MMult(m, MGetRotX(a.x));
        m = MMult(m, MGetRotY(a.y));
        m = MMult(m, MGetRotZ(a.z));
    }

    m.m[3][0] = pos.x;
    m.m[3][1] = pos.y;
    m.m[3][2] = pos.z;

    MV1SetMatrix(model, m);
}

static Vector3 VTransform(const Vector3& v, const MATRIX& m) {
	if (v == 0.0f) { return Vector3(); }
	return Vector3(VTransform(v.ToVECTOR(), m));
}

static std::string WStringToString(const std::wstring& ws)
{
	int len = WideCharToMultiByte(932, 0, ws.c_str(), -1, nullptr, 0, nullptr, nullptr);
	if (len <= 0) return {};
	std::string s(len - 1, '\0');
	WideCharToMultiByte(932, 0, ws.c_str(), -1, &s[0], len, nullptr, nullptr);
	return s;
}

/// <summary>
/// �l���ŏ��l�ƍő�l�̊ԂŐ��K������
/// </summary>
/// <param name="value">���݂̒l</param>
/// <param name="minValue">���̒l�ɂ�����ŏ��l</param>
/// <param name="maxValue">���̒l�ɂ�����ő�l</param>
/// <returns>���݂̒l�����̒l�ɂ����Ăǂ��Ɉʒu���Ă��邩�i ���� : 0.0f�`1.0f �j</returns>
static float ValueNormalizeRatio(float value, float minValue, float maxValue) {
	// 0���Z�h�~
	if (maxValue - minValue == 0.0f) { return 0.0f; }

	return (value - minValue) / (maxValue - minValue);
}

/// �����𔽓]������
static float RatioReverse(float ratio) { return (1.0f - ratio); }

// RGB�̐��l���J���[�R�[�h�ɕϊ�
static unsigned int RGBToColorCode(unsigned char r, unsigned char g, unsigned char b) { return ((r << 16) | (g << 8) | b); }

// MagicaVoxel�ɂ���č쐬����CSV�t�@�C����1�s�̏��̔ԍ�
enum CSV_ADDRESS { X, Z, Y, R, G, B, };

// MagicaVoxel�ɂ���č쐬����CSV�t�@�C����1�s������𔲂��o���\����
struct MagicaVoxelCSVRow {

	int x = -1, y = -1, z = -1;
	int number = 0;

	MagicaVoxelCSVRow(std::vector<std::string> line) {
		// XYZ
		x = std::stoi(line.at(CSV_ADDRESS::X));
		y = std::stoi(line.at(CSV_ADDRESS::Y));
		z = std::stoi(line.at(CSV_ADDRESS::Z));

		// RGB���J���[�R�[�h�ɕϊ����Ă����ԍ��Ƃ��Ďg��
		number = RGBToColorCode(
			std::stoi(line.at(CSV_ADDRESS::R)),
			std::stoi(line.at(CSV_ADDRESS::G)),
			std::stoi(line.at(CSV_ADDRESS::B))
		);
	}
};

/// <summary>
/// �z��S�Ă̗v�f��ϊ�����֐��i��Fstd::vector<int>����std::vector<float>�ցj
/// </summary>
/// <typeparam name="before">�ϊ����̌^</typeparam>
/// <typeparam name="after">�ϊ���̌^</typeparam>
/// <param name="array">�ϊ����̌^�̗v�f�����z��</param>
/// <returns>�ϊ���̌^�̗v�f�����z��</returns>
template<typename before, typename after>
static std::vector<after> ArrayCast(const std::vector<before>& array) {

    // �z�񐔎擾
    size_t size = array.size();

    // �ϊ���̌^�̔z����쐬����i�����l��0�j
    std::vector<after> ret(size, 0);

    // �ϊ��O�̌^�̔z���ϊ���̌^�̔z��ɃR�s�[���Ă���
    for (size_t i = 0; i < size; i++) { ret.at(i) = (after)array.at(i); }

    // �ϊ���̌^�̔z���Ԃ�
    return ret;
}

// %�ϊ�
static float PercentConversion(int percent) { return ((float)percent * 0.01f); }

template<typename T>
constexpr T UtilityClamp(const T& value, const T& min, const T& max)
{
    if (value < min) return min;
    if (value > max) return max;

    return value;
}